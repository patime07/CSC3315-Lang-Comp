#include "column.h"
#include <fstream>
#include <stdexcept>

// Save the column to a binary file
//void Column::saveToBinaryFile(std::ofstream &outFile) const {
    // Write column name size and the name itself
  //  size_t nameLength = name.size();
    //outFile.write(reinterpret_cast<const char*>(&nameLength), sizeof(nameLength));
    //outFile.write(name.c_str(), nameLength);

    // Write the data type size and the data type itself
    //size_t dataTypeLength = dataType.size();
    //outFile.write(reinterpret_cast<const char*>(&dataTypeLength), sizeof(dataTypeLength));
    //outFile.write(dataType.c_str(), dataTypeLength);
//}

// Load the column from a binary file
//void Column::loadFromBinaryFile(std::ifstream &inFile) {
    // Read column name length and the name itself
  //  size_t nameLength;
    //inFile.read(reinterpret_cast<char*>(&nameLength), sizeof(nameLength));
    //name.resize(nameLength);
    //inFile.read(&name[0], nameLength);

    // Read data type length and the data type itself
    //size_t dataTypeLength;
    //inFile.read(reinterpret_cast<char*>(&dataTypeLength), sizeof(dataTypeLength));
    //dataType.resize(dataTypeLength);
    //inFile.read(&dataType[0], dataTypeLength);
//}
