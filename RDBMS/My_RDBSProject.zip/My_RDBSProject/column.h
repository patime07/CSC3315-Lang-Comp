#ifndef COLUMN_H
#define COLUMN_H

#include <string>
#include <fstream> 

class Column {
private:
    std::string name;
    std::string dataType;

public:
    Column(const std::string& name = "", const std::string& dataType = "")
        : name(name), dataType(dataType) {}

    std::string getName() const;
    std::string getDataType() const;
    
    void print() const;
    void printHeader() const;
    
    void saveToBinaryFile(std::ofstream &outFile) const;
    void loadFromBinaryFile(std::ifstream &inFile);
};

#endif
