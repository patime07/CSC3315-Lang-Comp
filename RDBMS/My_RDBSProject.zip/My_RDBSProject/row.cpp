#include "row.h"

void Row::saveToBinaryFile(std::ofstream &outFile) const {
    size_t numValues = values.size();
    outFile.write(reinterpret_cast<const char*>(&numValues), sizeof(numValues));
    for (const auto &value : values) {
        size_t valueLength = value.length();
        outFile.write(reinterpret_cast<const char*>(&valueLength), sizeof(valueLength));
        outFile.write(value.c_str(), valueLength);
    }
}

void Row::loadFromBinaryFile(std::ifstream &inFile) {
    size_t numValues;
    inFile.read(reinterpret_cast<char*>(&numValues), sizeof(numValues));
    values.resize(numValues);
    for (auto &value : values) {
        size_t valueLength;
        inFile.read(reinterpret_cast<char*>(&valueLength), sizeof(valueLength));
        value.resize(valueLength);
        inFile.read(&value[0], valueLength);
    }
}

void Row::print() const {
    for (const auto &value : values) {
        std::cout << value << " ";
    }
    std::cout << std::endl;
}
