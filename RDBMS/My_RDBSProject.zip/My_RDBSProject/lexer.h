#ifndef LEXER_H
#define LEXER_H

#include <string>
#include "token.h"
using namespace std;

class Lexer {
private:
    string input;
    size_t index;  // Use size_t for indexing

public:
    Lexer(const string & input);
    Token getNextToken();
};

#endif
