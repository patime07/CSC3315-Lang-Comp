#ifndef ROW_H
#define ROW_H

#include <vector>
#include <string>
#include <fstream>
#include <iostream>

class Row {
private:
    std::vector<std::string> values;

public:
    Row() = default;  // Default constructor

    Row(const std::vector<std::string>& values) : values(values) {}

    void saveToBinaryFile(std::ofstream &outFile) const;
    void loadFromBinaryFile(std::ifstream &inFile);
    void print() const;
};

#endif
