#ifndef TOKEN_H
#define TOKEN_H

#include <string>
using namespace std;

// Define the TokenType enum
enum TokenType {
    CREATE, TABLE, INSERT, INTO, VALUES, SELECT, FROM, WHERE,
    INTEGER, VARCHAR, DATE, IDENTIFIER, NUMBER, STRING,
    STAR, COMMA, LPAREN, RPAREN, SEMICOLON, EQUALS, LESS, GREATER,
    NOT_EQUALS, LESS_EQUALS, GREATER_EQUALS, ERROR, END
};

// Define the Token class
class Token {
public:
    TokenType type;  // Type of token
    string value;    // Value of the token

    // Constructor for Token class (takes a TokenType and string)
    Token(TokenType t, const string& v) : type(t), value(v) {}

    // Default constructor (optional)
    Token() : type(ERROR), value("") {}
};

#endif
