#include "column.h"
#include <iostream>  // For std::cout

std::string Column::getName() const {
    return name;
}

std::string Column::getDataType() const {
    return dataType;
}

void Column::print() const {
    std::cout << name << ": " << dataType << std::endl;
}

void Column::printHeader() const {
    std::cout << name << " (" << dataType << ")";
}

// Save the column to a binary file
void Column::saveToBinaryFile(std::ofstream &outFile) const {
    size_t nameLength = name.length();
    outFile.write(reinterpret_cast<const char*>(&nameLength), sizeof(nameLength));
    outFile.write(name.c_str(), nameLength);

    size_t dataTypeLength = dataType.length();
    outFile.write(reinterpret_cast<const char*>(&dataTypeLength), sizeof(dataTypeLength));
    outFile.write(dataType.c_str(), dataTypeLength);
}

// Load the column from a binary file
void Column::loadFromBinaryFile(std::ifstream &inFile) {
    size_t nameLength;
    inFile.read(reinterpret_cast<char*>(&nameLength), sizeof(nameLength));
    name.resize(nameLength);
    inFile.read(&name[0], nameLength);

    size_t dataTypeLength;
    inFile.read(reinterpret_cast<char*>(&dataTypeLength), sizeof(dataTypeLength));
    dataType.resize(dataTypeLength);
    inFile.read(&dataType[0], dataTypeLength);
}
