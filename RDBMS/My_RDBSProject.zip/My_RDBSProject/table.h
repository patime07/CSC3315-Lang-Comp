#ifndef TABLE_H
#define TABLE_H

#include <string>
#include <vector>
#include "column.h"
#include "row.h"
#include <fstream>

class Table {
private:
    std::string name;
    std::vector<Column> columns;
    std::vector<Row> rows;

public:
    Table(const std::string &name = "") : name(name) {}
    
    void addColumn(const Column &column);
    void addRow(const Row &row);
    void saveToBinaryFile(std::ofstream &outFile) const;
    void loadFromBinaryFile(std::ifstream &inFile);
    void print() const;
    std::string getName() const { return name; }
};

#endif
