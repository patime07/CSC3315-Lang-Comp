#include "database.h"
#include <iostream>

void Database::addTable(const Table &table) {
    tables.push_back(table);
}

void Database::createTable(const std::string &tableName) {
    tables.push_back(Table(tableName));
}

void Database::addColumnToTable(const std::string &tableName, const Column &column) {
    Table* table = findTable(tableName);
    if (table) {
        table->addColumn(column);  // Adding the column to the table
    }
}

void Database::addRowToTable(const std::string &tableName, const Row &row) {
    Table* table = findTable(tableName);
    if (table) {
        table->addRow(row);  // Adding the row to the table
    }
}

void Database::saveToBinaryFile(std::ofstream &outFile) const {
    size_t numTables = tables.size();
    outFile.write(reinterpret_cast<const char*>(&numTables), sizeof(numTables));
    for (const auto &table : tables) {
        table.saveToBinaryFile(outFile);  // Delegate to Table's save method
    }
}

void Database::loadFromBinaryFile(std::ifstream &inFile) {
    size_t numTables;
    inFile.read(reinterpret_cast<char*>(&numTables), sizeof(numTables));
    tables.resize(numTables);
    for (auto &table : tables) {
        table.loadFromBinaryFile(inFile);  // Delegate to Table's load method
    }
}

void Database::print() const {
    for (const auto &table : tables) {
        table.print();  // Print each table
    }
}

Table* Database::findTable(const std::string &tableName) {
    for (auto &table : tables) {
        if (table.getName() == tableName) {
            return &table;
        }
    }
    return nullptr;  // Return nullptr if table is not found
}
