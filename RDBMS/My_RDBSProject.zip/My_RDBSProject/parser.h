#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"
#include "database.h"  // Ensure this include is here to use the Database class

class Parser {
private:
    Lexer & lexer;
    Token currentToken;
    Database & database;  // Ensure Database is properly declared

    void match(TokenType expected);
    void parseCreateStatement();
    void parseInsertStatement();
    void parseSelectStatement();

public:
    Parser(Lexer & lexer, Database & database);  // Constructor that initializes lexer and database
    void parseStatement();
};

#endif
