#ifndef DATABASE_H
#define DATABASE_H

#include <vector>
#include <string>
#include <fstream>
#include "table.h"

class Database {
private:
    std::vector<Table> tables;

public:
    void addTable(const Table &table);
    void createTable(const std::string &tableName);
    void addColumnToTable(const std::string &tableName, const Column &column);
    void addRowToTable(const std::string &tableName, const Row &row);
    void saveToBinaryFile(std::ofstream &outFile) const;
    void loadFromBinaryFile(std::ifstream &inFile);
    void print() const;
    Table* findTable(const std::string &tableName);
};

#endif
