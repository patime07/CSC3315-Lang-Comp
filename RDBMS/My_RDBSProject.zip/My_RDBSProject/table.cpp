#include "table.h"
#include <iostream>

void Table::addColumn(const Column &column) {
    columns.push_back(column);
}

void Table::addRow(const Row &row) {
    rows.push_back(row);
}

void Table::saveToBinaryFile(std::ofstream &outFile) const {
    size_t nameLength = name.length();
    outFile.write(reinterpret_cast<const char*>(&nameLength), sizeof(nameLength));
    outFile.write(name.c_str(), nameLength);

    size_t numColumns = columns.size();
    outFile.write(reinterpret_cast<const char*>(&numColumns), sizeof(numColumns));
    for (const auto &column : columns) {
        column.saveToBinaryFile(outFile);  // Delegate to Column's save method
    }

    size_t numRows = rows.size();
    outFile.write(reinterpret_cast<const char*>(&numRows), sizeof(numRows));
    for (const auto &row : rows) {
        row.saveToBinaryFile(outFile);  // Delegate to Row's save method
    }
}

void Table::loadFromBinaryFile(std::ifstream &inFile) {
    size_t nameLength;
    inFile.read(reinterpret_cast<char*>(&nameLength), sizeof(nameLength));
    name.resize(nameLength);
    inFile.read(&name[0], nameLength);

    size_t numColumns;
    inFile.read(reinterpret_cast<char*>(&numColumns), sizeof(numColumns));
    columns.resize(numColumns);
    for (auto &column : columns) {
        column.loadFromBinaryFile(inFile);  // Delegate to Column's load method
    }

    size_t numRows;
    inFile.read(reinterpret_cast<char*>(&numRows), sizeof(numRows));
    rows.resize(numRows);
    for (auto &row : rows) {
        row.loadFromBinaryFile(inFile);  // Delegate to Row's load method
    }
}

void Table::print() const {
    std::cout << "Table: " << name << std::endl;
    std::cout << "Columns:" << std::endl;
    for (const auto &col : columns) {
        col.printHeader();  // Print column headers
    }
    std::cout << "\nRows:" << std::endl;
    for (const auto &row : rows) {
        row.print();  // Print row data
    }
}
