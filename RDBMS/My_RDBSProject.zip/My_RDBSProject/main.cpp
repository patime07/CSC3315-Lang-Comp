#include "database.h"  // Ensure proper inclusion
#include "table.h"
#include "column.h"
#include "row.h"
#include <iostream> // for std::cout

using namespace std;

int main() {
    // Create a new database instance
    Database db;  // This should now be recognized
    
    // Create a table
    Table table("product");
    table.addColumn(Column("id", "INTEGER"));
    table.addColumn(Column("name", "VARCHAR"));
    table.addColumn(Column("price", "INTEGER"));
    
    // Add rows to the table
    Row row1({"11", "Table", "2600"});
    Row row2({"22", "Chair", "350"});
    table.addRow(row1);
    table.addRow(row2);
    
    // Add the table to the database
    db.addTable(table);

    // Save the database to a binary file
    ofstream outFile("database.dat", ios::binary);
    db.saveToBinaryFile(outFile);
    outFile.close();

    // Load the database from the binary file
    Database loadedDb;
    ifstream inFile("database.dat", ios::binary);
    loadedDb.loadFromBinaryFile(inFile);
    inFile.close();

    // Print the loaded database
    loadedDb.print();

    return 0;
}
